AURA — Fashion & Football Editorial Website
Student web design project.

Pages:
- index.html — Home
- courses.html — Collections
- about.html — Style Icons
- articles.html — Football Edit
- contact.html — Contact form

Features:
- Responsive navigation
- Responsive CSS Grid layouts
- Hover animations
- Editorial hero sections
- Celebrity / football-player visual concept
- Working front-end contact form validation
- Dynamic footer year

Note: The celebrity images are linked to Wikimedia Commons Special:FilePath URLs and other editorial web images, so an internet connection is needed to display them.
